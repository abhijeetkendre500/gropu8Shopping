
public class Main {

	public static void main(String[] args) {
		
		
		Player ashwin=new Player("Ashwin",455,"Bowler");
		Player shammi=new Player("Shammi",344,"Bowler");
		//Player p3=new Player();
		 
		if(ashwin.getWickets()>shammi.getWickets())
		{
			System.out.println("ashwin");
			
		}
		else
		{
			System.out.println("virat");
		}

	}

}
