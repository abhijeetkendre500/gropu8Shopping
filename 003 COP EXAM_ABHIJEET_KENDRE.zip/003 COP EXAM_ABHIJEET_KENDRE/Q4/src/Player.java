
public class Player {
       
	
	
	private String name;
	private int wickets;
	private String role;
	
	Player()
	{
    	this.name="name";
		this.wickets=0;
		this.role="r";
	}
	Player (String n,int w,String r)
	{
		this.name=n;
		this.wickets=w;
		this.role=r;
	}

	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name=name;
	}
	
	public int getWickets()
	{
		return wickets;
	}
	public void setWickets(int wickets)
	{
		this.wickets=wickets;
	}
	public String getRole()
	{
		return role;
	}
	public void setRole(String role)
	{
		this.role=role;
	}
	public String toString()
	{
		String str=" PlayerName:"+ name+"PlayerWickets:"+wickets+"PlayerRole:"+role;
		return str;
	}
}
